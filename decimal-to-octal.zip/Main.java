import java.util.Scanner;
public class Main{
    public static void main(String[] args){
        int r=0,sum = 0;
       Scanner n = new Scanner(System.in);
       int a = n.nextInt();
       if(a%8 != 0){
       while(a>0){
            r = a%8;
            sum = (sum*10)+r;
            a = a/8;
       }
    int c=0,d=0;
    while(sum>0){
        c = sum%10;
        d = (d*10)+c;
        sum = sum/10;
    }
        System.out.print(d);
    }
    else{
        System.out.print((a/8)*10);
    }
    }
}