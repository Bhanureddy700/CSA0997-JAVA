import jav.util.Scanner;
public static void R192111264{
    public static void main(String[] args){
     int i,j;
     Scanner temp = new Scanner(System.in);
     int n = temp.nextInt();
     System.out.println("1");
     c = "11";
     
     
     
    }
}