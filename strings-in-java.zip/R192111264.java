import java.util.Scanner;
public class R192111264{
public static void main(String[] args){
  int i;
Scanner n = new Scanner(System.in);
  String c = n.nextLine();
  char k = n.next().charAt(1);
  System.out.println(c);
  /*
  for(i=0;i<c.length();i++){
    if(c.charAt(i) == k){
      System.out.println(i);
    }
  }*/
}
}