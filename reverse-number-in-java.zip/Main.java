import java.util.Scanner;
public class Main{
    public static void main(String[] args){
        int r =0,sum = 0;
        Scanner n = new Scanner(System.in);
        int a = n.nextInt();
        while(a>0){
            r = a%10;
            sum = (sum*10)+r;
            a /= 10;
        }
        System.out.print(sum);
        
    }
}