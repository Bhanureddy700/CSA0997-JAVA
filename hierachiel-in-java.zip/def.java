class ijk{
    static void abc(){
        System.out.println("my self bhanu reddy");
    }
}
 public class def extends  ijk{
    public static void main(String[] args){
        def myobj = new def();
        myobj.abc();
    }
}