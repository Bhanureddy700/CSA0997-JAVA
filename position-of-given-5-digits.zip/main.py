k = "43251"
for i in range(1,len(k)+1):
    for j in range(1,len(k)+1):
        if(i == int(k[j-1])):
            print(str(i)+"-->"+str(j)+" position")