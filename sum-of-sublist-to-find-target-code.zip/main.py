import java.util.Scanner;
public class R192111264{
  public static void main(String[] args){
    int i,j;
Scanner temp = new Scanner(System.in);
int n = temp.nextInt();
int t = temp.nextInt();
int[] array = new int[n];
for(i=0;i<n;i++){
  array[i] = temp.nextInt();
}
for(i=0;i<n-1;i++){
  for(j=i+1;j<n;j++){
    if(array[i]+array[j]==t){
      System.out.println(i+" "+j);
      break;
    }
  }
}
}
}