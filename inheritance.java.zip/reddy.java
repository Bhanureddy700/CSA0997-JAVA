import java.util.Scanner;
 class main{
    static void bhanu(){
        String name = "hi my self bhanu prakash reddy";
        System.out.println(name);
    }
}
 public class reddy extends main{
    public static void main(String[] args){
        reddy hi = new reddy();
        hi.bhanu();
    }
}