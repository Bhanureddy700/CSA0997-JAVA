import java.util.Scanner;
public class bhanu{
    public static void main(String[] args){
        Scanner n = new Scanner(System.in);
        int c = n.nextInt();
        if(c>0){
        char a[] ={'1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
        int r=0;
        String h = "";
        while(c>0){
            r = c%16;
            h = a[r]+h;
            c =c/16;
        }
    System.out.println(h);
        }
        else if (c<0){
            char b[] ={'0','1'};
            c = c*(-1);
            int x =0;
            String z= " ";
             x = c;
            while(c>0){
                x = c%2;
                z = b[x]+z;
                c = c/2;
            }
          
        }
            
        }
    }